package sg.edu.rp.webservices.mydatabook;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class AboutUsActivity extends AppCompatActivity {
    ImageView iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        iv = findViewById(R.id.imageViewAbout);

        String imageUrl = "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_92x30dp.png";
        Picasso.with(this).load(imageUrl).placeholder(R.drawable.ajax_loader).error(R.drawable.error).into(iv);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}

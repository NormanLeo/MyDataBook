package sg.edu.rp.webservices.mydatabook;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class VaccinationFragment extends Fragment {
    Button btnEditVaccinate;
    TextView tvVaccinate;
    EditText etVaccinate;

    public VaccinationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_vaccination, container, false);
        // Inflate the layout for this fragment
        tvVaccinate = v.findViewById(R.id.textViewEditVaccinate);
        btnEditVaccinate = v.findViewById(R.id.buttonEditVaccinate);

        btnEditVaccinate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View viewV = inflater.inflate(R.layout.dialog_vaccinate, null);
                etVaccinate = viewV.findViewById(R.id.editTextEditBio);
                etVaccinate.setText(tvVaccinate.getText().toString());
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Edit Vaccination").setView(viewV).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        tvVaccinate.setText(etVaccinate.getText().toString());
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.show();
            }
        });

        return v;
    }

}

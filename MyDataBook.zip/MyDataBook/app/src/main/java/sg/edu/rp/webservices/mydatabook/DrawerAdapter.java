package sg.edu.rp.webservices.mydatabook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class DrawerAdapter extends ArrayAdapter<DrawerItem> {
    private ImageView iv;
    private TextView tv;
    private Context parent_context;
    private ArrayList<DrawerItem> itemList;

    public DrawerAdapter(Context context, int resource, ArrayList<DrawerItem> items){
        super(context, resource, items);
        this.parent_context = context;
        itemList = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        LayoutInflater inflater = (LayoutInflater) parent_context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.drawer_row, parent, false);
        tv = rowView.findViewById(R.id.textView);
        iv = rowView.findViewById(R.id.imageView);

        DrawerItem currentItem = itemList.get(position);
        iv.setImageDrawable(currentItem.draw);
        tv.setText(currentItem.getName());

        return rowView;
    }
}

package sg.edu.rp.webservices.mydatabook;

import android.graphics.drawable.Drawable;

public class DrawerItem{
    String name;
    Drawable draw;

    public DrawerItem(String name, Drawable draw) {
        this.name = name;
        this.draw = draw;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Drawable getDraw() {
        return draw;
    }

    public void setDraw(Drawable draw) {
        this.draw = draw;
    }
}

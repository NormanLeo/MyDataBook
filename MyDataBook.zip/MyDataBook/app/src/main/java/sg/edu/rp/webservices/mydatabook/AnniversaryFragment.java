package sg.edu.rp.webservices.mydatabook;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class AnniversaryFragment extends Fragment {
    Button btnEditAnniversary;
    TextView tvAnniversary;
    EditText etAnniversary;

    public AnniversaryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_anniversary, container, false);
        // Inflate the layout for this fragment
        tvAnniversary = v.findViewById(R.id.textViewAnniversary);
        btnEditAnniversary = v.findViewById(R.id.buttonEditAnniversary);

        btnEditAnniversary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View viewA = inflater.inflate(R.layout.dialog_anniversary, null);
                etAnniversary = viewA.findViewById(R.id.editTextEditAnniversary);
                etAnniversary.setText(tvAnniversary.getText().toString());
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Edit Anniversary").setView(viewA).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        tvAnniversary.setText(etAnniversary.getText().toString());
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.show();
            }
        });

        return v;
    }

}
